from django.contrib import admin
from .models import ECURecord, ECUConfig, KeyPair

admin.site.register(ECURecord)
admin.site.register(ECUConfig)
admin.site.register(KeyPair)   # 👈 you can add this down
