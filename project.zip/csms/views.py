from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.db import transaction
from django.contrib.auth.models import User

import json
import os
import secrets
from datetime import datetime, timedelta, timezone

from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization, hashes
from cryptography import x509
from cryptography.x509.oid import NameOID

from .models import ECUConfig, KeyPair


# ============================================================
# BASIC PAGES
# ============================================================

def main_login(request):
    return render(request, "main_login.html")

def home(request):
    return render(request, "home.html")

def csms_dashboard(request):
    return render(request, "csms_dashboard.html")

def csms_main(request):
    return render(request, "csms_main.html")

def debug(request):
    return render(request, "debug.html")

def debug_keygen(request):
    return render(request, "debug_keygen.html")


# ============================================================
# ADMIN
# ============================================================

def admin_dashboard(request):
    users = User.objects.all()
    return render(request, "admin_dashboard.html", {"users": users})


# ============================================================
# ECU
# ============================================================

def crc8_autosar(data):
    crc = 0xFF
    for ch in data:
        crc ^= ord(ch)
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x2F) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return format(crc ^ 0xFF, "02X")


@csrf_exempt
def generate_ecu_id(request):
    data = json.loads(request.body)
    base = f"{data['country']}-{data['oem']}-{data['plant']}"

    with transaction.atomic():
        obj, _ = ECUConfig.objects.get_or_create(base_ecu_id=base)
        obj.last_serial += 1
        obj.save()

    return JsonResponse({"ecu_id": base, "crc": crc8_autosar(base)})


@csrf_exempt
def set_ecu_password(request):
    return JsonResponse({"password": "generated-password"})


# ============================================================
# DOWNLOAD PLACEHOLDERS
# ============================================================

def download_text(request):
    return HttpResponse("Download text placeholder")

def download_xl(request):
    return HttpResponse("Download xl placeholder")

def download_aes_key(request):
    return HttpResponse("Download AES key placeholder")

def download_rsa_key(request):
    return HttpResponse("Download RSA key placeholder")


# ============================================================
# AES / RSA API
# ============================================================

@csrf_exempt
def generate_aes_key(request):
    key = os.urandom(16)
    nonce = os.urandom(12)
    return JsonResponse({"key": key.hex(), "nonce": nonce.hex()})


@csrf_exempt
def generate_rsa_key(request):
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )

    private_pem = private_key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption()
    ).decode()

    public_pem = private_key.public_key().public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo
    ).decode()

    return JsonResponse({
        "private_key": private_pem,
        "public_key": public_pem
    })


def file_encryption_view(request):
    return render(request, "encrypt.html")


def decrypt_file_view(request):
    return render(request, "decrypt.html")


# ============================================================
# SEED
# ============================================================

@csrf_exempt
def generate_seed(request):
    return JsonResponse({"seed": secrets.token_hex(8)})


@csrf_exempt
def process_seed(request):
    return JsonResponse({"result": "processed"})


def seed_key_generation(request):
    return render(request, "seed_key_generation.html")


# ============================================================
# PDF
# ============================================================

def pdf_policy(request):
    return redirect("/media/policies/csms_policy.pdf")


# ============================================================
# INCIDENT
# ============================================================

def incident_email(request):
    return render(request, "incident_email.html")


# ============================================================
# DIGITAL CERTIFICATE PAGE
# ============================================================

def digital_certificate_page(request):
    return render(request, "digital_certificate.html")


# ============================================================
# OEM KEY
# ============================================================

@csrf_exempt
def generate_oem_key(request):
    if request.method == "POST":

        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )

        private_pem = private_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()
        ).decode()

        public_pem = private_key.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()

        KeyPair.objects.create(
            key_type="OEM",
            private_key=private_pem,
            public_key=public_pem
        )

        return render(request, "digital_certificate.html", {
            "private_key": private_pem,
            "public_key": public_pem,
            "success_message": "OEM Key Generated Successfully"
        })

    return redirect("digital_certificate")


# ============================================================
# OEM CERTIFICATE
# ============================================================

@csrf_exempt
def generate_certificate(request):
    if request.method == "POST":

        oem_key = KeyPair.objects.filter(key_type="OEM").last()
        if not oem_key:
            return render(request, "digital_certificate.html", {
                "error_message": "Generate OEM key first."
            })

        private_key = serialization.load_pem_private_key(
            oem_key.private_key.encode(),
            password=None
        )

        now = datetime.now(timezone.utc)

        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, "IN"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "CSMS OEM"),
            x509.NameAttribute(NameOID.COMMON_NAME, "OEM Root CA"),
        ])

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(private_key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + timedelta(days=3650))
            .add_extension(
                x509.BasicConstraints(ca=True, path_length=None),
                critical=True
            )
            .sign(private_key, hashes.SHA256())
        )

        return render(request, "digital_certificate.html", {
            "subject": cert.subject.rfc4514_string(),
            "issuer": cert.issuer.rfc4514_string(),
            "serial": cert.serial_number,
            "valid_from": cert.not_valid_before,
            "valid_to": cert.not_valid_after,
            "fingerprint": cert.fingerprint(hashes.SHA256()).hex(),
            "success_message": "OEM Root Certificate Generated Successfully"
        })

    return redirect("digital_certificate")


# ============================================================
# INTERMEDIATE KEY
# ============================================================

@csrf_exempt
def generate_intermediate_key(request):
    if request.method == "POST":

        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048
        )

        private_pem = private_key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()
        ).decode()

        public_pem = private_key.public_key().public_bytes(
            serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo
        ).decode()

        KeyPair.objects.create(
            key_type="INTERMEDIATE",
            private_key=private_pem,
            public_key=public_pem
        )

        return render(request, "digital_certificate.html", {
            "private_key": private_pem,
            "public_key": public_pem,
            "success_message": "Intermediate Key Generated Successfully"
        })

    return redirect("digital_certificate")


# ============================================================
# INTERMEDIATE CERTIFICATE
# ============================================================

@csrf_exempt
def generate_intermediate_certificate(request):
    if request.method == "POST":

        oem_key = KeyPair.objects.filter(key_type="OEM").last()
        intermediate_key = KeyPair.objects.filter(key_type="INTERMEDIATE").last()

        if not oem_key or not intermediate_key:
            return render(request, "digital_certificate.html", {
                "error_message": "Generate OEM and Intermediate keys first."
            })

        oem_private = serialization.load_pem_private_key(
            oem_key.private_key.encode(),
            password=None
        )

        intermediate_private = serialization.load_pem_private_key(
            intermediate_key.private_key.encode(),
            password=None
        )

        now = datetime.now(timezone.utc)

        subject = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, "IN"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "CSMS Intermediate"),
            x509.NameAttribute(NameOID.COMMON_NAME, "Intermediate CA"),
        ])

        issuer = x509.Name([
            x509.NameAttribute(NameOID.COUNTRY_NAME, "IN"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "CSMS OEM"),
            x509.NameAttribute(NameOID.COMMON_NAME, "OEM Root CA"),
        ])

        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(intermediate_private.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now)
            .not_valid_after(now + timedelta(days=3650))
            .add_extension(
                x509.BasicConstraints(ca=True, path_length=None),
                critical=True
            )
            .sign(oem_private, hashes.SHA256())
        )

        return render(request, "digital_certificate.html", {
            "subject": cert.subject.rfc4514_string(),
            "issuer": cert.issuer.rfc4514_string(),
            "serial": cert.serial_number,
            "valid_from": cert.not_valid_before,
            "valid_to": cert.not_valid_after,
            "fingerprint": cert.fingerprint(hashes.SHA256()).hex(),
            "success_message": "Intermediate Certificate Generated Successfully"
        })

    return redirect("digital_certificate")
