from django.db import models


# ================= ECU RECORD =================
class ECURecord(models.Model):
    plant_id = models.CharField(max_length=50)
    ecu_id = models.CharField(max_length=20, unique=True)
    sw_version = models.CharField(max_length=50)

    prng_type = models.CharField(max_length=20)   # CSPRNG, TRNG, Custom
    password_length = models.IntegerField()       # 32 or 64
    password = models.TextField()

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.ecu_id


# ================= ECU CONFIG =================
class ECUConfig(models.Model):
    """
    Stores last used serial number for each ECU configuration
    Example base_ecu_id:
    IN-RNE-DL1-EPS-H2-2603-L3
    """
    base_ecu_id = models.CharField(max_length=100, unique=True)
    last_serial = models.IntegerField(default=0)

    def __str__(self):
        return self.base_ecu_id


# ================= SYSTEM USERS (LOGIN + ROLES) =================
class SystemUser(models.Model):
    ROLE_CHOICES = [
        ("MASTER_ADMIN", "Master Admin"),
        ("POWER_USER", "Power User"),
        ("RESTRICTED", "Restricted User"),
        ("GUEST", "Guest"),
    ]

    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=100)   # will hash later
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.username} - {self.role}"


# ================= KEY PAIR STORAGE =================
class KeyPair(models.Model):

    KEY_TYPES = [
        ("OEM", "OEM"),
        ("INTERMEDIATE", "INTERMEDIATE"),
        ("SIGNING", "SIGNING"),
    ]

    key_type = models.CharField(max_length=20, choices=KEY_TYPES)
    private_key = models.TextField()
    public_key = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.key_type
