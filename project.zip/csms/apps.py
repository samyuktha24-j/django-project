from django.apps import AppConfig


class CsmsConfig(AppConfig):
    name = 'csms'
