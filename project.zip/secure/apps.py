from django.apps import AppConfig


class SecureConfig(AppConfig):
    name = 'secure'
